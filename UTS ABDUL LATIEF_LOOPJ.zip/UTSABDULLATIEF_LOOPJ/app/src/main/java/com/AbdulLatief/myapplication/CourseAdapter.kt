package com.AbdulLatief.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Recycler
import coil.load
import com.AbdulLatief.myapplication.databinding.ItemCourseBinding

class CourseAdapter (val data : ArrayList<Course>) :
RecyclerView.Adapter<CourseAdapter.CourseViewHolder>(){

    class CourseViewHolder(val view : ItemCourseBinding)  : RecyclerView.ViewHolder(view.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CourseViewHolder {
        val view = ItemCourseBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CourseViewHolder(view)
    }

    override fun getItemCount() = data.size
    override fun onBindViewHolder(holder: CourseViewHolder, position: Int) {
        val Course = data[position]
        holder.view.tvTitle.text = Course.title
        holder.view.tvPath.text = Course.path
        holder.view.ivCourse.load(Course.image)
    }
}